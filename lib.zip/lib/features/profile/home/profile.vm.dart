import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:manager/core/models/profile_model.dart';
import 'package:manager/routes/routes.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../core/locator.dart';
import '../../../core/models/hive/user/user.dart' as hive_user;
import '../../../core/storage/storage.dart';
import '../../../core/utils/failures.dart';
import '../../../services/auth.service.dart';
import '../../../services/profile.service.dart';
import '../../../services/account.service.dart';
import '../../../core/utils/app_logger.dart';
import 'package:fluttertoast/fluttertoast.dart';

class ProfileViewModel extends ReactiveViewModel {
  final _navigationService = locator<NavigationService>();
  final _authService = locator<AuthService>();
  final _profileService = locator<ProfileService>();

  final _user = ReactiveValue(getUser());
  hive_user.User get user => _user.value;

  final _profile = ReactiveValue<ProfileModel?>(null);
  ProfileModel? get profile => _profile.value;

  final _isLoading = ReactiveValue<bool>(false);
  bool get isLoading => _isLoading.value;

  void init() {
     _profileService.refreshProfile();
     loadProfileData();
  }

  Future<void> loadProfileData() async {
    _isLoading.value = true;
    notifyListeners();

    try {
      // Get profile data from ProfileService (no API call)
      final profile = _profileService.globalProfileModel;
      if (profile != null) {
        _profile.value = profile;
        AppLogger.info('Profile data loaded from ProfileService ${_profile.value?.completionPercentage??"nocode"}');
      } else {
        AppLogger.warning('No profile data available in ProfileService');
      }
    } catch (e) {
      AppLogger.error('Error loading profile data: $e');
      Fluttertoast.showToast(
        msg: 'Error loading profile data: $e',
        backgroundColor: Colors.red,
      );
    } finally {
      _isLoading.value = false;
      notifyListeners();
    }
  }

  void navigateToQRView() async {
    await _navigationService.navigateTo(Routes.qr);
  }

  void navigateToCreateOrEditOrgView() async {

    await _profileService.refreshProfile();
    await loadProfileData();
    await _navigationService.navigateTo(Routes.updateOrg);

    // No need to fetch profile data - it will be updated by ProfileService
    // when the update-profile API is called
  }

  void navigateToLoginView() async {
    hive_user.User currentUser = getUser();

    if (currentUser.email != null) {
      await AccountManagerService.instance.saveCurrentUser(currentUser);
    }

    String? fcmToken = getUser().fcmToken;
    _authService.logout(fcmToken);
  }

  Future<bool> deleteAccount() async {
    hive_user.User currentUser = getUser();

    if (currentUser.email != null) {
      await AccountManagerService.instance.saveCurrentUser(currentUser);
    }

    Either<Failure, bool> res=await _authService.deleteAccount(id: currentUser.id??'');
    res.fold((l) {
      return false;
    }, (r) {
      return true;
    });
    return false;
  }

  void navigateToGeneralSetting() async {

    await _navigationService.navigateTo(Routes.generalSetting);
  }

  @override
  List<ReactiveServiceMixin> get reactiveServices => [];
}
