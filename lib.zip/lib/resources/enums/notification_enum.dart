enum NotificationType {
  organizationRequest,
  ticketRequest,
}
