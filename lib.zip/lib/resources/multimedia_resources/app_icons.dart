part of 'resources.dart';
